config = {
    "secret": "74feOnf3y5FGWxUAu86HjC9BH6Kjcyocf7Pg6R8AB5xcSvZZQaOVrXh9NQFrVhyrUmZlrRcfgRUjZSWNKMXaQcNMhFc1aXkV0g4xKvuNxLQqhib6V5F8MImUkKMaF4Tm",
    "client_id": "uk9J8GNpAn4lnYmwiR77zKMpAW1AwlPkmObkumfa",
}